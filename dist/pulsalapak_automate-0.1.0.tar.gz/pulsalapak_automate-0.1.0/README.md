# pulsalapak-automate
An educational purpose to automate pulsalapak.
